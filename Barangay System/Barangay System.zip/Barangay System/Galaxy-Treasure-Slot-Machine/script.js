/* ============================================================
   Apex Premium Slot Machine — Main JavaScript
   
   This script powers the slot machine game logic,
   including:
   - Deposit System (players start with 0 coins)
   - Betting System (Bet 10, 20, 50)
   - Staggered Reel Spinning Animation
   - Payout Calculations (Jackpot = Bet x 5, Win = Bet x 2)
   - Statistics Tracking & History Panel
   - Auto Spin (5 spins)
   - Settings (Sound, Music, Dark Mode, Fullscreen)
   ============================================================ */

// ==================== SYMBOL DEFINITIONS ====================
const symbols = [
    "image1.png",
    "image2.png",
    "image3.png"
];

// ==================== GAME STATE ====================
let coins = 0;
let currentBet = 10;
let totalSpins = 0;
let totalWins = 0;
let totalLosses = 0;
let jackpotWins = 0;
let highestBalance = 0;
let totalCoinsWon = 0;

let isSpinning = false;
let isAutoSpinning = false;
let autoSpinsLeft = 0;
let spinHistory = [];

let isDarkMode = true;
let isSoundOn = true;
let isMusicOn = false;

// Audio Object for spinning
const spinAudio = new Audio('audio.mp3');
spinAudio.loop = true;

// ==================== DOM ELEMENTS ====================
// Reels
const reel1 = document.getElementById('reel-1');
const reel2 = document.getElementById('reel-2');
const reel3 = document.getElementById('reel-3');
const reelBox1 = document.getElementById('reel-box-1');
const reelBox2 = document.getElementById('reel-box-2');
const reelBox3 = document.getElementById('reel-box-3');
const reelBoxes = [reelBox1, reelBox2, reelBox3];

// Player Stats Bar
const playerBalanceEl = document.getElementById('player-balance');
const playerBetEl = document.getElementById('player-bet');
const playerTotalWonEl = document.getElementById('player-total-won');
const playerJackpotsEl = document.getElementById('player-jackpots');

// Deposit
const depositInput = document.getElementById('deposit-input');
const depositBtn = document.getElementById('deposit-btn');
const depositError = document.getElementById('deposit-error');
const quickDepositBtns = document.querySelectorAll('.btn-quick-deposit');

// Bet buttons
const betBtns = document.querySelectorAll('.btn-bet');

// Main Controls
const spinBtn = document.getElementById('spin-btn');
const autoSpinBtn = document.getElementById('auto-spin-btn');
const resetBtn = document.getElementById('reset-btn');

// Overlays & Messages
const resultMessage = document.getElementById('result-message');
const resultText = document.getElementById('result-text');
const noCoinsOverlay = document.getElementById('no-coins-overlay');
const noCoinsMsg = document.getElementById('no-coins-msg');
const noCoinsClose = document.getElementById('no-coins-close');
const loadingScreen = document.getElementById('loading-screen');

// Statistics Display
const statCoins = document.getElementById('stat-coins');
const statBet = document.getElementById('stat-bet');
const statSpins = document.getElementById('stat-spins');
const statWins = document.getElementById('stat-wins');
const statLosses = document.getElementById('stat-losses');
const statJackpots = document.getElementById('stat-jackpots');
const statHighest = document.getElementById('stat-highest');
const statTotalWon = document.getElementById('stat-total-won');

// Spin History
const historyList = document.getElementById('history-list');

// Settings Toggles
const soundBtn = document.getElementById('sound-btn');
const musicBtn = document.getElementById('music-btn');
const darkModeBtn = document.getElementById('dark-mode-btn');
const fullscreenBtn = document.getElementById('fullscreen-btn');

// Background/Effects Containers
const starsContainer = document.getElementById('stars-container');
const confettiContainer = document.getElementById('confetti-container');

// ==================== INITIALIZATION ====================
function init() {
    setupEventListeners();
    updateUI();

    // Hide loading screen
    setTimeout(() => {
        if (loadingScreen) {
            loadingScreen.classList.add('hidden');
        }
    }, 1000);
}

document.addEventListener('DOMContentLoaded', init);

// ==================== EVENT LISTENERS ====================
function setupEventListeners() {
    // Deposit Events
    depositBtn.addEventListener('click', handleDepositSubmit);
    depositInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') handleDepositSubmit();
    });
    quickDepositBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const amount = parseInt(btn.getAttribute('data-amount'), 10);
            if (!isNaN(amount) && amount > 0) {
                depositCoins(amount);
            }
        });
    });

    // Bet selection events
    betBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            if (isSpinning) return;
            const betVal = parseInt(btn.getAttribute('data-bet'), 10);
            if (!isNaN(betVal)) {
                currentBet = betVal;
                betBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                updateUI();
                
                // Audio placeholder: click sound
                // playSound('click');
            }
        });
    });

    // Controls
    spinBtn.addEventListener('click', handleSpin);
    autoSpinBtn.addEventListener('click', handleAutoSpin);
    resetBtn.addEventListener('click', handleReset);
    noCoinsClose.addEventListener('click', () => {
        noCoinsOverlay.classList.add('hidden');
    });

    // Settings
    soundBtn.addEventListener('click', toggleSound);
    musicBtn.addEventListener('click', toggleMusic);
    darkModeBtn.addEventListener('click', toggleDarkMode);
    fullscreenBtn.addEventListener('click', toggleFullscreen);

    // Keyboard Shortcuts: Spacebar to Spin
    document.addEventListener('keydown', (e) => {
        if (e.code === 'Space') {
            // Prevent spacebar from scrolling or double clicking buttons
            if (document.activeElement.tagName !== 'INPUT') {
                e.preventDefault();
                if (!isSpinning) handleSpin();
            }
        }
    });
}

// ==================== DEPOSIT SYSTEM ====================
function handleDepositSubmit() {
    const val = depositInput.value.trim();
    if (val === '') return;

    const amount = Number(val);
    if (!Number.isInteger(amount) || amount <= 0) {
        showDepositError('Please enter a positive whole number.');
        return;
    }

    showDepositError(''); // Clear error
    depositCoins(amount);
    depositInput.value = '';
}

function depositCoins(amount) {
    coins += amount;
    if (coins > highestBalance) highestBalance = coins;
    updateUI();
    animateBalanceChange();
    
    // Audio placeholder: coin deposit sound
    // playSound('deposit');
}

function showDepositError(msg) {
    if (msg) {
        depositError.textContent = msg;
        depositError.classList.remove('hidden');
    } else {
        depositError.classList.add('hidden');
    }
}

// ==================== GAMEPLAY FUNCTIONS ====================
function handleSpin() {
    if (isSpinning) return;

    // Verify deposit
    if (coins <= 0) {
        showNoCoinsOverlay("You have 0 coins. Please deposit coins to start spinning!");
        return;
    }

    // Verify bet amount
    if (coins < currentBet) {
        showNoCoinsOverlay(`Insufficient coins for bet of ${currentBet}. Deposit coins or select a lower bet!`);
        return;
    }

    // Reset overlay
    noCoinsOverlay.classList.add('hidden');

    // Deduct bet
    coins -= currentBet;
    totalSpins++;
    isSpinning = true;
    updateUI();

    // Disable inputs & buttons
    setControlsDisabled(true);
    resultMessage.classList.add('hidden');
    clearReelHighlights();

    // Start reel animations
    const finalResults = [
        getRandomSymbol(),
        getRandomSymbol(),
        getRandomSymbol()
    ];

    startSpinAnimation(finalResults);
}

function getRandomSymbol() {
    const idx = Math.floor(Math.random() * symbols.length);
    return symbols[idx];
}

function startSpinAnimation(finalResults) {
    const reelImages = [reel1, reel2, reel3];
    const intervals = [];

    if (isSoundOn) {
        spinAudio.currentTime = 0;
        spinAudio.play().catch(err => console.log("Audio play failed (audio.mp3 may be missing):", err));
    }

    // Run spin intervals to show fast rolling images
    for (let i = 0; i < 3; i++) {
        reelBoxes[i].classList.add('spinning');
        reelBoxes[i].classList.remove('stopped');

        intervals[i] = setInterval(() => {
            reelImages[i].src = getRandomSymbol();
        }, 70);
    }

    // Stop Reel 1
    setTimeout(() => {
        clearInterval(intervals[0]);
        reelImages[0].src = finalResults[0];
        reelBoxes[0].classList.remove('spinning');
        reelBoxes[0].classList.add('stopped');
    }, 700);

    // Stop Reel 2
    setTimeout(() => {
        clearInterval(intervals[1]);
        reelImages[1].src = finalResults[1];
        reelBoxes[1].classList.remove('spinning');
        reelBoxes[1].classList.add('stopped');
    }, 1300);

    // Stop Reel 3 and evaluate
    setTimeout(() => {
        clearInterval(intervals[2]);
        reelImages[2].src = finalResults[2];
        reelBoxes[2].classList.remove('spinning');
        reelBoxes[2].classList.add('stopped');

        evaluateResult(finalResults);
    }, 1900);
}

function evaluateResult(results) {
    const [r1, r2, r3] = results;
    let winAmount = 0;
    let outcome = '';

    // Triple match - Jackpot
    if (r1 === r2 && r2 === r3) {
        winAmount = currentBet * 5;
        outcome = 'jackpot';
        jackpotWins++;
        totalWins++;
        totalCoinsWon += winAmount;

        showResult(`🎉 JACKPOT! +${winAmount} Coins! (Bet × 5)`, 'jackpot');
        reelBoxes.forEach(box => box.classList.add('jackpot-highlight'));
        launchConfetti();

        // Audio placeholder: jackpot win
        // playSound('jackpot');

    // Double match - Small Win
    } else if (r1 === r2 || r2 === r3 || r1 === r3) {
        winAmount = currentBet * 2;
        outcome = 'match';
        totalWins++;
        totalCoinsWon += winAmount;

        showResult(`✨ Nice Match! +${winAmount} Coins! (Bet × 2)`, 'match');

        // Highlight matching reels
        if (r1 === r2) {
            reelBoxes[0].classList.add('win-highlight');
            reelBoxes[1].classList.add('win-highlight');
        }
        if (r2 === r3) {
            reelBoxes[1].classList.add('win-highlight');
            reelBoxes[2].classList.add('win-highlight');
        }
        if (r1 === r3) {
            reelBoxes[0].classList.add('win-highlight');
            reelBoxes[2].classList.add('win-highlight');
        }

        // Audio placeholder: normal win
        // playSound('win');

    // Lose
    } else {
        outcome = 'lose';
        totalLosses++;
        showResult('Better luck next spin!', 'lose');
        
        // Audio placeholder: lose sound
        // playSound('lose');
    }

    // Update coins
    coins += winAmount;
    if (coins > highestBalance) highestBalance = coins;

    // Add to history
    addToHistory(results, outcome, winAmount);

    // Pause spin audio
    spinAudio.pause();

    // Update Displays
    updateUI();
    isSpinning = false;
    setControlsDisabled(false);

    // Handle Auto Spin queue
    if (isAutoSpinning) {
        autoSpinsLeft--;
        if (autoSpinsLeft > 0 && coins >= currentBet) {
            setTimeout(handleSpin, 1200);
        } else {
            isAutoSpinning = false;
            autoSpinsLeft = 0;
            updateAutoSpinButton();
            if (coins < currentBet) {
                showNoCoinsOverlay("Auto spin stopped due to insufficient coins.");
            }
        }
    }
}

function handleAutoSpin() {
    if (isAutoSpinning) {
        // Stop it
        isAutoSpinning = false;
        autoSpinsLeft = 0;
        updateAutoSpinButton();
        return;
    }

    if (coins < currentBet) {
        showNoCoinsOverlay("You need enough coins for your selected bet to Auto Spin.");
        return;
    }

    isAutoSpinning = true;
    autoSpinsLeft = 5;
    updateAutoSpinButton();
    handleSpin();
}

function updateAutoSpinButton() {
    if (isAutoSpinning) {
        autoSpinBtn.querySelector('.btn-text').textContent = `STOP (${autoSpinsLeft})`;
        autoSpinBtn.classList.add('active');
    } else {
        autoSpinBtn.querySelector('.btn-text').textContent = 'AUTO SPIN (5×)';
        autoSpinBtn.classList.remove('active');
    }
}

function handleReset() {
    // Reset state
    coins = 0;
    currentBet = 10;
    totalSpins = 0;
    totalWins = 0;
    totalLosses = 0;
    jackpotWins = 0;
    highestBalance = 0;
    totalCoinsWon = 0;

    isSpinning = false;
    isAutoSpinning = false;
    autoSpinsLeft = 0;
    spinHistory = [];

    // Reset bet button styling
    betBtns.forEach(btn => {
        const betVal = parseInt(btn.getAttribute('data-bet'), 10);
        if (betVal === 10) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    // Reset reels
    reel1.src = symbols[0];
    reel2.src = symbols[1];
    reel3.src = symbols[2];

    clearReelHighlights();
    resultMessage.classList.add('hidden');
    noCoinsOverlay.classList.add('hidden');
    updateAutoSpinButton();
    updateUI();
    renderHistory();
}

// ==================== UI UPDATES ====================
function updateUI() {
    // Player Stats Bar
    playerBalanceEl.textContent = coins;
    playerBetEl.textContent = currentBet;
    playerTotalWonEl.textContent = totalCoinsWon;
    playerJackpotsEl.textContent = jackpotWins;

    // Stats Panel
    statCoins.textContent = coins;
    statBet.textContent = currentBet;
    statSpins.textContent = totalSpins;
    statWins.textContent = totalWins;
    statLosses.textContent = totalLosses;
    statJackpots.textContent = jackpotWins;
    statHighest.textContent = highestBalance;
    statTotalWon.textContent = totalCoinsWon;
}

function animateBalanceChange() {
    playerBalanceEl.classList.remove('coin-pop');
    void playerBalanceEl.offsetWidth; // Trigger reflow
    playerBalanceEl.classList.add('coin-pop');
}

function setControlsDisabled(disabled) {
    spinBtn.disabled = disabled;
    resetBtn.disabled = disabled;
    depositBtn.disabled = disabled;
    quickDepositBtns.forEach(btn => btn.disabled = disabled);

    // Keep auto spin button clickable during auto spin so it can be stopped
    if (!isAutoSpinning) {
        autoSpinBtn.disabled = disabled;
    } else {
        autoSpinBtn.disabled = false;
    }
}

function clearReelHighlights() {
    reelBoxes.forEach(box => {
        box.classList.remove('win-highlight', 'jackpot-highlight', 'stopped');
    });
}

function showResult(message, type) {
    resultText.textContent = message;
    resultMessage.className = `result-message ${type}`;
    resultMessage.classList.remove('hidden');
}

function showNoCoinsOverlay(msg) {
    noCoinsMsg.textContent = msg;
    noCoinsOverlay.classList.remove('hidden');
}

// ==================== HISTORY PANEL ====================
function addToHistory(results, outcome, winAmount) {
    const entry = {
        results: [...results],
        outcome: outcome,
        bet: currentBet,
        win: winAmount
    };

    spinHistory.unshift(entry);
    if (spinHistory.length > 5) {
        spinHistory.pop();
    }
    renderHistory();
}

function renderHistory() {
    if (spinHistory.length === 0) {
        historyList.innerHTML = '<p class="history-empty">No spins yet — deposit coins and start playing!</p>';
        return;
    }

    let html = '';
    spinHistory.forEach((entry, idx) => {
        let label = '';
        let tagClass = '';

        if (entry.outcome === 'jackpot') {
            label = `🎉 Jackpot (+${entry.win})`;
            tagClass = 'jackpot-tag';
        } else if (entry.outcome === 'match') {
            label = `✨ Win (+${entry.win})`;
            tagClass = 'match-tag';
        } else {
            label = '💫 Lose';
            tagClass = 'lose-tag';
        }

        html += `
            <div class="history-entry" style="animation-delay: ${idx * 0.05}s">
                <div class="history-images">
                    <img src="${entry.results[0]}" alt="reel1">
                    <img src="${entry.results[1]}" alt="reel2">
                    <img src="${entry.results[2]}" alt="reel3">
                </div>
                <span class="history-bet">Bet: ${entry.bet}</span>
                <span class="history-result ${tagClass}">${label}</span>
            </div>
        `;
    });

    historyList.innerHTML = html;
}

// ==================== SETTINGS & TOGGLES ====================
function toggleSound() {
    isSoundOn = !isSoundOn;
    if (isSoundOn) {
        soundBtn.querySelector('.btn-icon').textContent = '🔊';
        soundBtn.querySelector('.btn-text').textContent = 'SOUND ON';
        soundBtn.classList.add('active');
    } else {
        soundBtn.querySelector('.btn-icon').textContent = '🔇';
        soundBtn.querySelector('.btn-text').textContent = 'SOUND OFF';
        soundBtn.classList.remove('active');
        spinAudio.pause();
    }
}

function toggleMusic() {
    isMusicOn = !isMusicOn;
    if (isMusicOn) {
        musicBtn.querySelector('.btn-icon').textContent = '🎵';
        musicBtn.querySelector('.btn-text').textContent = 'MUSIC ON';
        musicBtn.classList.add('active');
    } else {
        musicBtn.querySelector('.btn-icon').textContent = '🎵';
        musicBtn.querySelector('.btn-text').textContent = 'MUSIC OFF';
        musicBtn.classList.remove('active');
    }
}

function toggleDarkMode() {
    isDarkMode = !isDarkMode;
    if (isDarkMode) {
        document.body.classList.remove('light-mode');
        darkModeBtn.querySelector('.btn-icon').textContent = '🌙';
        darkModeBtn.querySelector('.btn-text').textContent = 'DARK MODE';
        darkModeBtn.classList.add('active');
    } else {
        document.body.classList.add('light-mode');
        darkModeBtn.querySelector('.btn-icon').textContent = '☀️';
        darkModeBtn.querySelector('.btn-text').textContent = 'LIGHT MODE';
        darkModeBtn.classList.remove('active');
    }
}

function toggleFullscreen() {
    if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().then(() => {
            fullscreenBtn.querySelector('.btn-text').textContent = 'EXIT FULL';
            fullscreenBtn.classList.add('active');
        }).catch((err) => {
            console.warn(`Fullscreen error: ${err.message}`);
        });
    } else {
        document.exitFullscreen().then(() => {
            fullscreenBtn.querySelector('.btn-text').textContent = 'FULLSCREEN';
            fullscreenBtn.classList.remove('active');
        });
    }
}

// ==================== BACKGROUND EFFECTS ====================
function createStars() {}

function createShootingStars() {}

function launchConfetti() {
    if (!confettiContainer) return;
    const colors = ['#fbbf24', '#ef4444', '#ec4899', '#a855f7', '#6366f1', '#34d399', '#22d3ee'];
    const numPieces = 50;

    for (let i = 0; i < numPieces; i++) {
        const piece = document.createElement('div');
        piece.classList.add('confetti-piece');
        piece.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        piece.style.left = `${Math.random() * 100}%`;

        const size = Math.random() * 7 + 5;
        piece.style.width = `${size}px`;
        piece.style.height = `${size * (Math.random() * 0.6 + 0.4)}px`;

        const cDur = Math.random() * 2 + 1.5;
        const cDelay = Math.random() * 0.5;
        piece.style.setProperty('--c-dur', `${cDur}s`);
        piece.style.setProperty('--c-delay', `${cDelay}s`);

        confettiContainer.appendChild(piece);

        setTimeout(() => {
            piece.remove();
        }, (cDur + cDelay) * 1000 + 200);
    }
}
